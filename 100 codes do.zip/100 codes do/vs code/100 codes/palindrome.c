#include<stdio.h> 
int main ()
{
    int n, sum = 0, a, temp;
    printf("The number is: ");
    scanf("%d",&n);
    temp = n;
    //loop to find reverse number
    while(temp != 0)
    {
        a= temp % 10;
        sum = sum * 10 + a;
        temp /= 10;
    };
    // palindrome if num and reverse are equal
    if (n == sum)
        printf("%d is Palindrome\n", n);
    else
        printf("%d is Not Palindrome\n", n);

}
