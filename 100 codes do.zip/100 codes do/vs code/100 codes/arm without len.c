#include<stdio.h> 
#include<math.h>
int main ()
{
    int n,sum = 0,a,temp,count = 0;
    printf("The number is: ");
    scanf("%d",&n);
    temp = n;
    while(n != 0)  
    {  
       n=n/10;  
       count++;  
    }  
    n = temp;
    while(n > 0)
    {
        a = n % 10;
        a = pow(a,count);
        sum = sum + a;
        n  /= 10;
    }
    if( sum == temp)
        printf("  Armstrong");
    else
        printf(" Not Armstrong\n");

}
