#include<stdio.h> 
int main ()
{
    int n,sum = 0,a,temp;
    printf("The number is: ");
    scanf("%d",&n);
    temp = n;
    while(n > 0)
    {
        a = n % 10;
        sum = sum +(a * a * a);
        n /= 10;
    }
    if(temp == sum)
        printf("%d is Armstrong\n",temp);
    else
        printf("%d is Not Armstrong\n",temp);

}
