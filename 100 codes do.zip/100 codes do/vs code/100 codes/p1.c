// Online C compiler to run C program online
#include <stdio.h>

int main() {
     int n,rem,sum=0,n1,i,a,rev=0;
     printf("Enter n:");
     scanf("%d",&n);
     for(i=0;i<=n;i++)
     {
         printf("elements: ");
         scanf("%d",&a);
         rev = 0;
         while(a>0)
         {
           rem = a % 10;
           rev = (rev*10) + (rem);
           a /= 10;
         } 
         sum = sum + rev;
         
     }
     
      printf("%d",sum);
     
    
     return 0;
}