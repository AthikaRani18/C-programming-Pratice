#include<stdio.h>
void main()
{
    int n1,n2,sum=0;
    printf("Enter a starting number:");
    scanf("%d",&n1);
    printf("Enter a ending number:");
    scanf("%d",&n2);
    for(int i = n1;i<=n2;i++)
    {
       
          sum = sum + i;

    } 
    printf("%d",sum);
}