#include <stdio.h>
#include<string.h>

int main() {
    int str[50],str2[50];
    printf("Enter string:");
    scanf("%s",&str);
    printf("Enter string:");
    scanf("%s",&str2);
    strcat(str,str2);
    printf("%s",str);
    return 0;
       
}