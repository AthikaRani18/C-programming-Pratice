#include<stdio.h>
void main()
{
    int num ;
    printf("Enter a number ");
    scanf("%d",&num);
    if(num >0)
      printf("The number is positive");
    else 
      printf("the number is negative");
}