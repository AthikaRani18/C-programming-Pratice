#include<stdio.h>
void main()
{
    int n1,n2;
    printf("Enter a starting number:");
    scanf("%d",&n1);
    printf("Enter a ending number:");
    scanf("%d",&n2);
    if(n1>n2)
    printf("%d is greater ",n1);
    else 
        printf("%d is greater ",n2);

}