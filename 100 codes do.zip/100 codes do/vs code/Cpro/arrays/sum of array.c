#include<stdio.h>
void main()
{
   int  n,a[100],i,count=0;
   printf("Enter a number:");
   scanf("%d",&n);
   printf("Enter the n elements");
   
   for(i=0;i<n;i++)
   {
     scanf("%d",&a[i]);
   }
   for(i=0;i<n;i++)
   {
    
      count = count + a[i];
   }
   printf("the count is %d",count);
   return 0;
}