// Online C compiler to run C program online
#include <stdio.h>
int main() {
    int a=7;// Write C code here
    printf("%d %d %d %d %d %d",a++,++a,--a,a--,a++,a--);
    return 0;
}






