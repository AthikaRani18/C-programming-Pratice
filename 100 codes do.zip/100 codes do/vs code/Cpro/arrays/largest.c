#include<stdio.h>
void main()
{
   int  n,a[100],i,max;
   printf("Enter a number:");
   scanf("%d",&n);
   printf("Enter the n elements");
   
   for(i=0;i<n;i++)
   {
     scanf("%d",&a[i]);
   }
   max= a[0];
   for(i=1;i<n;i++)
   {
      if(a[i] >  max)
      {
           max  = a[i];
      }
   }
   printf("the largest number is %d",max);
   return 0;

    }
