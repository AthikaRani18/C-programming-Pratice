#include<stdio.h>
void main()
{
   int  n,a[100],i,max,min;
   printf("Enter a number:");
   scanf("%d",&n);
   printf("Enter the n elements");
   
   for(i=0;i<=n;i++)
   {
     scanf("%d",&a[i]);
   }
   max= a[0];
   for(i=1;i<=n;i++)
   {
      if(a[i] >  max)
      {
           max  = a[i];
      }
   }
   i = 0;
   min = a[0];
   for(i=1;i<=n;i++)
   {
      if(a[i] <  min)
      {
           min  = a[i];
      }
   }
   printf("the Smallest and largest number is %d and %d",min,max);
   return 0;

    }
