   #include <stdio.h>  
   int main() 
   {  
    int a[100], b[100];  
    int n, i, j, count;  
    printf("Enter Number of Elements in Array");
    scanf("%d", &n);
    printf("Enter %d numbers",n);
    for(i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
        b[i] = -1;
    }
    for(i = 0; i < n; i++) 
    {  
        count = 1;  
        for(j = i+1; j < n; j++) {  
            if(a[i]==a[j]) {
                b[j] = 0;    
                count++;
            }  
        }  
        if(b[i]!=0) 
        {  
            b[i] = count;  
        }  
    }  
    /* Print count of each element */   
    for(i = 0; i<n; i++) {  
        if(b[i] != 0) {  
            printf("Element %d : Count %d\n",a[i], b[i]);  
        }  
    }  
   
    return 0;  
}  