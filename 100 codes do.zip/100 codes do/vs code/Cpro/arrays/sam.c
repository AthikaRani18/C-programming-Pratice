// Online C compiler to run C program online
#include <stdio.h>

int main() {

int x[3][3]={(1,2,3),(4,5,6), (7,8,9)};
printf(" %d %d %d ", (x+2), *(x+2), *(*x+1)+2);
    return 0;
}