#include<stdio.h>
void main()
{
   int  n,a[100],i,min;
   printf("Enter a number:");
   scanf("%d",&n);
   printf("Enter the n elements");
   
   for(i=0;i<n;i++)
   {
     scanf("%d",&a[i]);
   }
   min= a[0];
   for(i=1;i<n;i++)
   {
      if(a[i] <  min)
      {
           min = a[i];
      }
   }
   printf("the smallest number is %d",min);
   return 0;

    }
