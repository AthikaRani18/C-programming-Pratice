#include<stdio.h>
void main()
{
   int  n,a[100],i,j,temp;
   printf("Enter a number:");
   scanf("%d",&n);
   printf("Enter the n elements");
   
   for(i=0;i<n;i++)
   {
     scanf("%d",&a[i]);
   }
   for(i=0;i<n;i++)
   {
    for(j=0;j<n/2;j++)
    {
        if(a[j] > a[j+1])
        {
            temp = a[j];
            a[j] = a[j+1];
            a[j+1] = temp;
        }
    }
    for(j=n/2;j<n;j++)
    {
        if(a[j] < a[j+1])
        {
            temp = a[j];
            a[j] = a[j+1];
            a[j+1] = temp;
        }
    }
   
   } 
   for(i=0;i<n;i++)
    printf(" %d",a[i]);
   return 0;
}