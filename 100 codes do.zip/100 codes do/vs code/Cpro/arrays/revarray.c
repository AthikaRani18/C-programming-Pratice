
#include <stdio.h>
int main()
{
    int a[100], n, i, t, end;
    
    scanf("%d", &n);
    end = n - 1;
    
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    
    for (i = 0; i < n/2; i++) {
        t = a[i];
        a[i] = a[end];
        a[end] = t;    
        end--;
    }
    
    printf("Reversed array elements are:\n");
    
    for (i = 0; i < n; i++) {
        printf("%d\n", a[i]);
    }
    
    return 0;
}

