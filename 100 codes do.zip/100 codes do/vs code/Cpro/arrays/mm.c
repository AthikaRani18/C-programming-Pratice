#include<stdio.h>
int main()
{
    int heights[5],i;
    printf("Enter elements:");
    for(i=0;i<7;i++)
    {
        scanf("%d",&heights[i]);
    }
    printf("Elements:");
    for(i=0;i<7;i++)
    {
        printf("%d\n",heights[i]);
    }
}