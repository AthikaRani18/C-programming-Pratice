#include<stdio.h>
int main()
{
    char s[100],i;
    printf("Enter character: ");
    scanf("%s",&s);
    for(i=0;s[i] !='\0';i++)
    {
         if(s[i] >= 'a' && s[i] <= 'z')
        {
            s[i] = s[i] + 'A' - 'a';
        }
        else  if(s[i] >= 'A' && s[i] <= 'Z')
        {
            s[i] = s[i] + 'a' - 'A';
        }
       
    }
     printf("%s",s);
     return 0;
}

