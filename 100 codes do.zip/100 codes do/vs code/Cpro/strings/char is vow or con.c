#include<stdio.h>
int main()
{
    char s;
    printf("Enter character: ");
    scanf("%c",&s);
    if(s == 'a' || s=='e' || s == 'i' || s=='o' || s=='u' || s == 'A' || s=='E' || s == 'I' || s=='O' || s=='U')
    {
        printf("Vowel");
    }
    else 
    {
        printf("Consonants");
    }
    return 0;
}