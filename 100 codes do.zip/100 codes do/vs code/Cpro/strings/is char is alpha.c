#include<stdio.h>
int main()
{
    char s;
    printf("Enter character: ");
    scanf("%c",&s);
    if((s >= 'a' && s <= 'z') || (s >= 'A' && s <= 'Z'))
    {
        printf("is alphabet");
    }
    else
    {
        printf("not");
    }
return 0;
}