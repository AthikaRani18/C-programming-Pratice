#include<stdio.h>
#include<string.h>
int main()
{
    int i,n,j=0;
    char s[100],sum[0];
    printf("Enter n");
    scanf("%d",&n);
    for(i=1;i!=0;i++)
    {   
        if(i<=n)
        {
            printf("Enter character:");
            scanf("%c",&s[i]);
            sum[j] = s[i];
            j++;
        }
    }
    printf("%s",sum[j]);
    return 0;
}