#include<stdio.h>
int main()
{
    char s[100],i,count=0;
    printf("Enter word: ");
    scanf("%s",&s);
    for(i=0;s[i] !='\0';i++)
    {
        count = count + 1;
    }
            printf("%d",count);
    return 0;
}
    