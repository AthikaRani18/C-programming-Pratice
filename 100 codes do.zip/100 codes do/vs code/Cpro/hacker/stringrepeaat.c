#include <stdio.h>

int main()
{
    char str[100],temp;
    int i,j,max =0;

    printf("Enter string:");
    scanf("%s",str);
              

    for(i=0;str[i] != '\0';i++)
    { 
      int count = 1;
      for(j=i+1;str[j] != '\0';j++)
      {
         if(str[i] == str[j])
           count = count+1;
         if(count>=max)
          {
            max = count;
            temp = str[i];
          }
      }
      
    }
     printf("%c : %d",temp,max);
      
      return 0;
}