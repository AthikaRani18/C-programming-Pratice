#include<stdio.h>
int main()
{
    int a[100],i,j,k,n;
    printf("Enter k:");
    scanf("%d",&k);
    printf("Enter n:");
    scanf("%d",&n);
    printf("Enter elements:");
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    int start =0, end =k-1;
    for(i=0; i<= end ; i++)
    {
         int max=0;
        for(j = start ;j<=end;j++)
        {
            if(a[j]> max)
            {
                max = a[j];
            }
        }
        printf("%d\n",max);
        start ++;
        end ++;
        
    }
    
      

        return 0;

     

}