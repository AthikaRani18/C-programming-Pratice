#include<stdio.h>
int main()
{
    int n,count=0,i;
    printf("Enter n:");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        if(n%i == 0)
        {
            count = count +1;
        }
    }
        if(count > 2)
        {
            if(n%2 == 0)
            printf("even");
            else 
            printf("odd");
        }
        else
        {
            printf("prime");
        }

    }
    