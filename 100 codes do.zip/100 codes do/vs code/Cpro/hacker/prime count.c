#include <stdio.h> 

int main() {
  int n, i, c = 0,a=0,r;
  printf("Enter any number n:");
  scanf("%d", &n);
  while(n!=0)
  {
     r = n%10;
     for (i = 1; i <= r; i++)
     {
          if ((r % i == 0))
          {
             c++;
          }
     }
     
     if ((c == 2) || (c==1))
     {
        a = a+1;
     }
     n=n/10;
     c=0;
 }
  printf("%d\n",a);
  
  return 0;
}