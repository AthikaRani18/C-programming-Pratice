#include <stdio.h>
int main()
{
  int i,n,j,count=0;
  char str[100];
  printf("Enter string:");
  scanf("%s",&str);
  for(i=0;str[i] != '\0';i++)
  {
      count = count +1;
  }
  for(i=0;i<count;i++)
  {
      for(j=0;j<count;j++)
      { 
        if(i==j)
        {
          printf("%c ",str[i]);
        }
         else if (i+j == count-1)
          {
              printf("%c ",str[j]);
          
          }
        
        else
         {
          printf(" ");
         }
        
      }
      printf("\n");
  }

    return 0;
}
