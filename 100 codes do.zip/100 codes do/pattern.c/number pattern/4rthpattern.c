#include<stdio.h>
int main()
{
    int n ,i,j;
    printf("enter n:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        for(j=0;j<n-i;j++) 
        {
           
               printf(" %d ",i+1);
            
        }
        printf("\n");
    }
    return 0;
}