#include<stdio.h>
int main()
{
    int n ,i,j,k;
    printf("enter n:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        for(k=n-i;k != 0 ; k--)
            {
                printf(" ");
            }
            
        for(j=0;j<n;j++)
        {
            if(i==0 || i==n-1 || j==n-1 || j==0 )
            {
                printf("*");
            }
            else 
            {
                printf(" ");
            }
            

        }
        printf("\n");
    }
    return 0;
}