#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

  int n,i,j;
  printf("Enter the n:");
  scanf("%d",&n);
  if(n%2 == 1)
  {
    for(i=0;i<n;i++)
    {
       for(j=0;j<n;j++)
       {
          if((i==j)||(i+j == n-1))
          {
              printf("*");
          }
          else 
          {
              printf(" ");
          }
       }
      printf("\n");
     } 
  }
    else
    {
       for(i=0;i<n/2;i++)
       {
         for(j=0;j<n;j++)
         {
            if((i==j)||(i+j == n-1))
            {
              printf("*");
            }
            else 
            {
                printf(" ");
            }
          }
        printf("\n");
       }
    
      for(i=(n/2)+1;i<n;i++)
       {
         for(j=0;j<n;j++)
         {
            if((i==j)||(i+j == n-1))
            {
              printf("*");
            }
            else 
            {
                printf(" ");
            }
          }
        printf("\n");
      }
       
    }
        
      /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}
