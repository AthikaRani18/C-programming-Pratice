#include<stdio.h>
int main()
{
    int n,i,j;
    printf("enter n: ");
    scanf("%d",&n);
    for(i=0;i<=n;i++)
    {
        for(j=0;j<=n;j++)
        {
            if((i==0) || (j==n) || (i==n) || (j==0))
                printf("*");
            else 
               printf(" ");
        }
        printf("\n");
    }
    return 0;
}