#include<stdio.h>
int main()
    {
        int i,n=5;
        for(i=0;i<n;i++)
        {
          if(i != 0)
          {
            printf("even\n");
            continue;
            printf("Hi");
          }
          printf("Hi");
          printf("\n");
         }
    }
